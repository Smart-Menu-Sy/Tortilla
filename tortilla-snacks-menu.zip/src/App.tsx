import React, { useState, useEffect, useMemo } from 'react';
import Papa from 'papaparse';
import { Search, ShoppingCart, Plus, Minus, Phone, X, Utensils, Image as ImageIcon, Loader2 } from 'lucide-react';
import { MenuItem, CartItem } from './types';

const CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSCRSNikIu7I5siUPfUBq0hqUOXj2TrA-Vjvh3gadJCE3tqyB8P7KejE9NILzUKw6MbTNuS_sWvONql/pub?output=csv';

export default function App() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    const fetchUrl = `${CSV_URL}&t=${new Date().getTime()}`;
    Papa.parse(fetchUrl, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data as MenuItem[];
        const cleanData = data.map(item => ({
          ...item,
          name: item.name?.trim() || '',
          category: item.category?.trim() || '',
          desc: item.desc?.trim() || '',
          price: item.price?.trim() || '',
          img: item.img?.trim() || ''
        }));
        
        const validData = cleanData.filter(item => item.name && item.category);
        setItems(validData);

        const cats = Array.from(new Set(validData.map(item => item.category)));
        setCategories(['الكل', ...cats]);
        setLoading(false);
      },
      error: (err) => {
        setError('حدث خطأ أثناء جلب البيانات. يرجى المحاولة لاحقاً.');
        setLoading(false);
      }
    });
  }, []);

  const getPriceNum = (priceStr: string | undefined | null) => {
    if (!priceStr) return 0;
    const num = parseInt(priceStr.toString().replace(/\D/g, ''), 10);
    return isNaN(num) ? 0 : num;
  };

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.item.name === item.name);
      if (existing) {
        return prev.map(c => c.item.name === item.name ? { ...c, quantity: c.quantity + 1 } : c);
      }
      return [...prev, { item, quantity: 1 }];
    });
  };

  const removeFromCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.item.name === item.name);
      if (existing && existing.quantity > 1) {
        return prev.map(c => c.item.name === item.name ? { ...c, quantity: c.quantity - 1 } : c);
      }
      return prev.filter(c => c.item.name !== item.name);
    });
  };

  const getCartQuantity = (item: MenuItem) => {
    const found = cart.find(c => c.item.name === item.name);
    return found ? found.quantity : 0;
  };

  const cartTotal = cart.reduce((acc, curr) => acc + (getPriceNum(curr.item.price) * curr.quantity), 0);
  const cartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !address.trim()) {
      alert('الرجاء إدخال الاسم والعنوان/رقم الطاولة');
      return;
    }

    let text = `*طلب جديد من:* ${customerName}\n`;
    text += `*العنوان/الطاولة:* ${address}\n\n`;
    text += `*التفاصيل:*\n`;
    cart.forEach(c => {
       const p = getPriceNum(c.item.price);
       const priceStr = p === 0 ? "حسب الاختيار" : `${(p * c.quantity).toLocaleString('ar-SY')} ل.س`;
       text += `- ${c.quantity}x ${c.item.name} (${priceStr})\n`;
    });
    text += `\n*الإجمالي:* ${cartTotal > 0 ? cartTotal.toLocaleString('ar-SY') + ' ل.س' : 'حسب الاختيار'}\n`;
    if (notes.trim()) text += `\n*ملاحظات:* ${notes}\n`;

    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/963941991104?text=${encoded}`, '_blank');
    setIsModalOpen(false);
    setCart([]);
  };

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return items.filter(item => {
      const matchCat = selectedCategory === 'الكل' || item.category === selectedCategory;
      const matchSearch = !q || item.name.toLowerCase().includes(q) || item.desc.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [items, selectedCategory, searchQuery]);

  return (
    <div className="h-screen flex flex-col font-sans bg-brand-bg text-brand-dark relative">
      {/* Faint Background Image */}
      <div 
        className="absolute inset-0 z-0 opacity-10 pointer-events-none bg-center bg-no-repeat bg-contain"
        style={{ backgroundImage: "url('https://i.ibb.co/nMJVHFfy/tortilla.jpg')" }}
      />
      
      {/* Content Wrapper */}
      <div className="relative z-10 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="bg-brand-dark text-white p-6 shadow-lg flex-none relative">
          <div className="max-w-4xl mx-auto flex justify-between items-start">
            <div className="flex items-center gap-4">
              <img src="https://i.ibb.co/nMJVHFfy/tortilla.jpg" alt="Tortilla Snacks Logo" className="w-16 h-16 object-cover bg-white rounded-full p-1 border-2 border-brand-accent/20 shadow-sm" onError={(e) => e.currentTarget.style.display = 'none'} />
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Tortilla Snacks</h1>
                <p className="text-brand-bg/80 text-sm mt-1">طعم يتخطى الخيال .. بروح منعشة وخفيفة</p>
              </div>
            </div>
            <div className="flex gap-3">
             <div className="flex flex-col items-end gap-2">
                <div className="flex gap-2">
                  <a href="https://wa.me/963941991104" target="_blank" rel="noreferrer" className="bg-[#25D366] p-2 rounded-full hover:opacity-90 flex items-center justify-center text-white" aria-label="WhatsApp">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>
                  </a>
                  <a href="https://www.instagram.com/tortilla_snacks?igsh=MXNhaTB2NjY1dWVoaw==" target="_blank" rel="noreferrer" className="p-2 rounded-full hover:opacity-90 flex items-center justify-center text-white" aria-label="Instagram" style={{ background: 'radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%,#d6249f 60%,#285AEB 90%)' }}>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" /></svg>
                  </a>
                  <a href="https://facebook.com" target="_blank" rel="noreferrer" className="bg-[#1877F2] p-2 rounded-full hover:opacity-90 flex items-center justify-center text-white" aria-label="Facebook">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                  </a>
                </div>
                <div className="flex gap-2 text-xs text-brand-bg/90 font-mono mt-1 font-bold">
                  <a href="tel:0941991104" className="hover:text-white transition">0941991104</a>
                  <span>/</span>
                  <a href="tel:0991115239" className="hover:text-white transition">0991115239</a>
                </div>
             </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow overflow-y-auto p-4 custom-scroll">
        <div className="max-w-4xl mx-auto">
        {loading ? (
          <div className="flex flex-col items-center justify-center mt-20 text-brand-primary">
            <Loader2 className="animate-spin mb-4" size={48} />
            <p className="font-bold">جاري تحميل المنيو الشهي...</p>
          </div>
        ) : error ? (
          <div className="text-brand-accent text-center mt-20 font-bold bg-white p-6 rounded-xl mx-4 shadow-sm">
            {error}
          </div>
        ) : (
          <>
            {/* Search and Filters */}
            <nav className="mb-6 space-y-4">
              <div className="relative max-w-2xl mx-auto">
                <input 
                  type="text" 
                  placeholder="ابحث عن وجبتك المفضلة..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white border border-brand-primary/20 rounded-2xl py-4 px-12 text-brand-dark focus:outline-none focus:ring-2 focus:ring-brand-primary shadow-sm"
                />
                <Search className="w-5 h-5 absolute right-4 top-1/2 -translate-y-1/2 text-brand-primary" />
              </div>
              
              <div className="flex gap-3 overflow-x-auto pb-2 custom-scroll scroll-smooth">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-6 py-2 rounded-xl whitespace-nowrap font-medium transition-all ${
                      selectedCategory === cat 
                        ? 'bg-brand-primary text-white' 
                        : 'bg-white text-brand-primary border border-brand-primary/20 hover:bg-brand-primary/5'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </nav>

            {/* Menu Items */}
            <div>
              {categories.filter(cat => cat !== 'الكل' && (selectedCategory === 'الكل' || selectedCategory === cat)).map(cat => {
                const catItems = filteredItems.filter(item => item.category === cat);
                if (catItems.length === 0) return null;
                
                return (
                  <div key={cat} className="mb-10">
                    <h2 className="text-2xl font-black text-brand-dark mb-4 pb-2 border-b-2 border-brand-primary/10 flex items-center gap-2">
                      <Utensils className="text-brand-accent" size={24} />
                      {cat}
                    </h2>
                    <div className="flex flex-col gap-4 content-start">
                      {catItems.map(item => {
                        const qty = getCartQuantity(item);
                        const isCustomPrice = getPriceNum(item.price) === 0;

                        return (
                          <div key={item.name} className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-brand-primary/5 flex items-center justify-between hover:shadow-md transition-shadow gap-4">
                            <div className="flex-grow">
                              <h3 className="font-bold text-lg text-brand-dark mb-1">{item.name}</h3>
                              <p className="text-sm text-gray-500 leading-relaxed mb-2">{item.desc}</p>
                              <span className="text-brand-accent font-black">
                                {isCustomPrice ? 'حسب الاختيار' : `${getPriceNum(item.price).toLocaleString('ar-SY')} `}
                                {!isCustomPrice && <small className="text-[11px] font-bold">ل.س</small>}
                              </span>
                            </div>
                            
                            <div className="flex-none flex items-center">
                              {qty > 0 ? (
                                <div className="flex items-center gap-3 bg-brand-bg rounded-xl px-2 py-1">
                                  <button 
                                    onClick={() => addToCart(item)}
                                    className="text-brand-primary font-bold text-xl px-2 hover:opacity-80 transition"
                                  >
                                    +
                                  </button>
                                  <span className="font-bold text-base min-w-[2ch] text-center">{qty}</span>
                                  <button 
                                    onClick={() => removeFromCart(item)}
                                    className="text-brand-accent font-bold text-xl px-2 hover:opacity-80 transition"
                                  >
                                    -
                                  </button>
                                </div>
                              ) : (
                                <button 
                                  onClick={() => addToCart(item)}
                                  className="bg-brand-primary text-white p-3 rounded-xl hover:bg-brand-dark transition shadow-sm flex items-center gap-2"
                                >
                                  <Plus size={20} />
                                  <span className="hidden sm:inline text-sm font-bold">إضافة</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
              {filteredItems.length === 0 && (
                <div className="py-12 text-center text-gray-500 font-medium">
                  عذراً، لم نتمكن من العثور على أطباق تطابق بحثك.
                </div>
              )}
            </div>
          </>
        )}
        </div>
      </main>

      {/* Floating Cart Footer */}
      {cartCount > 0 && (
        <footer className="p-4 bg-brand-bg flex-none z-20">
          <div className="max-w-md mx-auto bg-brand-accent text-white rounded-3xl p-4 shadow-xl flex items-center justify-between relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-0.5">
                <span className="bg-white text-brand-accent w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs">
                  {cartCount}
                </span>
                <span className="font-medium">طلب في السلة</span>
              </div>
              <p className="text-xl font-bold">
                الإجمالي: {cartTotal > 0 ? cartTotal.toLocaleString('ar-SY') + ' ل.س' : 'حسب الاختيار'}
              </p>
            </div>
            <button 
              onClick={() => setIsModalOpen(true)} 
              className="relative z-10 bg-white text-brand-accent font-bold px-8 py-3 rounded-2xl hover:bg-brand-bg transition-colors"
            >
              اطلب الآن
            </button>
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full"></div>
          </div>
          <div className="text-center mt-3">
            <p className="text-[10px] text-brand-primary/60 uppercase tracking-widest">Powered by Tortilla Tech • 2024</p>
          </div>
        </footer>
      )}

      {/* Checkout Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="bg-brand-dark text-white p-5 flex justify-between items-center">
              <h2 className="text-xl font-bold">تأكيد الطلب</h2>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-white/20 rounded-full transition">
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto hide-scrollbar">
              <form id="checkout-form" onSubmit={handleCheckout} className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">الاسم <span className="text-brand-accent">*</span></label>
                  <input 
                    required 
                    type="text" 
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition bg-gray-50 focus:bg-white"
                    placeholder="الاسم الكريم"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">العنوان / رقم الطاولة <span className="text-brand-accent">*</span></label>
                  <input 
                    required 
                    type="text" 
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition bg-gray-50 focus:bg-white"
                    placeholder="رقم الطاولة أو العنوان للتوصيل"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">ملاحظات التعديل (اختياري)</label>
                  <textarea 
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent transition bg-gray-50 focus:bg-white resize-none"
                    placeholder="مثال: بدون بصل، زيادة صوص..."
                    rows={3}
                  ></textarea>
                </div>

                <div className="mt-6 pt-6 border-t border-gray-100">
                  <h3 className="font-bold text-gray-800 mb-3">ملخص الطلب:</h3>
                  <div className="bg-brand-bg rounded-xl p-4 space-y-2 mb-4">
                    {cart.map((c, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="font-medium">{c.quantity}x {c.item.name}</span>
                        <span className="text-gray-600">
                          {getPriceNum(c.item.price) === 0 ? "حسب الاختيار" : `${(getPriceNum(c.item.price) * c.quantity).toLocaleString('ar-SY')} ل.س`}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between items-center font-black text-lg">
                    <span>الإجمالي:</span>
                    <span className="text-brand-accent">
                      {cartTotal > 0 ? cartTotal.toLocaleString('ar-SY') + ' ل.س' : 'حسب الاختيار'}
                    </span>
                  </div>
                </div>
              </form>
            </div>

            <div className="p-5 border-t border-gray-100 bg-gray-50">
              <button 
                type="submit" 
                form="checkout-form"
                className="w-full bg-brand-primary hover:bg-brand-dark text-white py-4 rounded-xl font-bold flex justify-center items-center gap-2 transition shadow-md"
              >
                إرسال الطلب عبر الواتساب
                <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
              </button>
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}
