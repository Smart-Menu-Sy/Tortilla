export interface MenuItem {
  name: string;
  category: string;
  price: string;
  desc: string;
  img: string;
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
}
